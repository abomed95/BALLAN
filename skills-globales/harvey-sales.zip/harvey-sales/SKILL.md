---
name: harvey-sales
description: >-
  B2B sales and outbound playbook (from the open-source Harvey sales agent, MIT).
  Use when the user wants to write or review a cold email or LinkedIn message,
  qualify a lead (BANT, MEDDIC, ICP), find prospects or buying signals, plan an
  account approach, build an offer, handle a sales objection or reply, or sell
  to startups. Also triggers on: prospection, e-mail de prospection, relance,
  objection client, qualification de leads, offre commerciale.
---

# harvey-sales

Sales knowledge base taken from Harvey (github.com/ethanplusai/harvey, MIT,
(c) Ethan Rogers). This skill gives the knowledge only: it never sends e-mails
or messages itself. Claude drafts, the user decides and sends.

## Which reference to read

Read only the file(s) the task needs, from `references/` in this skill's folder:

| Task | File |
| --- | --- |
| Write / review a cold email, subject line, follow-up sequence | `email_frameworks.md` (+ `signal_playbook.md` for the opening line) |
| Find prospects, where to look, trigger events | `prospecting_tactics.md` |
| Qualify a lead, ICP score, BANT / MEDDIC, disqualify | `lead_qualification.md` |
| Several contacts in one company, who to write to first | `account_navigation.md` |
| Turn a signal (hiring, funding, tech stack) into a hook | `signal_playbook.md` |
| Conversation flow, tone, ethics | `sales_methodology.md` |
| What to offer at each stage, closing, timing | `offer_strategy.md` |
| Answer an objection or a reply | `objection_handling.md` |
| LinkedIn connection and messages | `linkedin_outreach.md` |
| Prospect is a startup (YC, accelerator, recent raise) | `selling_to_startups.md` |

## How to work

1. Ask for (or infer from the conversation) the product/offer, the target and
   the prospect's facts. Never invent a fact about a prospect, a client name, a
   number or a result: leave a visible placeholder like `[chiffre à confirmer]`.
2. Apply the reference's rules, then fill the `{{placeholders}}` of its templates
   with real data only.
3. The "Compliance & Deliverability" rules in `email_frameworks.md` override
   style rules: truthful subject lines, real identity, working opt-out, honour
   every "stop" immediately, legitimate-interest basis for EU/UK prospects.
4. Write in the prospect's language (French, English, Arabic...). The references
   are in English; adapt idioms, do not translate them word for word.
5. Deliver drafts the user can copy. Never send anything through a connector
   (Gmail, LinkedIn...) unless the user explicitly asks for that specific send.
